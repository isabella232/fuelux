/*
 * Fuel UX
 * https://github.com/ExactTarget/fuelux
 *
 * Copyright (c) 2012 ExactTarget
 * Licensed under the MIT license.
 */

define('jquery', [], function () { return jQuery; });

define('moment', [], function () {});

define('fuelux/loader', ['fuelux/all'], function () {});

require('fuelux/loader');